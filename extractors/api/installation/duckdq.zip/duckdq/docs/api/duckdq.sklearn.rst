duckdq.sklearn package
======================

Submodules
----------

duckdq.sklearn.data\_quality module
-----------------------------------

.. automodule:: duckdq.sklearn.data_quality
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: duckdq.sklearn
   :members:
   :undoc-members:
   :show-inheritance:
