duckdq.core package
===================

Submodules
----------

duckdq.core.metrics module
--------------------------

.. automodule:: duckdq.core.metrics
   :members:
   :undoc-members:
   :show-inheritance:

duckdq.core.preconditions module
--------------------------------

.. automodule:: duckdq.core.preconditions
   :members:
   :undoc-members:
   :show-inheritance:

duckdq.core.properties module
-----------------------------

.. automodule:: duckdq.core.properties
   :members:
   :undoc-members:
   :show-inheritance:

duckdq.core.states module
-------------------------

.. automodule:: duckdq.core.states
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: duckdq.core
   :members:
   :undoc-members:
   :show-inheritance:
