duckdq.engines package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   duckdq.engines.pandas
   duckdq.engines.sql

Submodules
----------

duckdq.engines.engine module
----------------------------

.. automodule:: duckdq.engines.engine
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: duckdq.engines
   :members:
   :undoc-members:
   :show-inheritance:
