duckdq.engines.pandas package
=============================

Submodules
----------

duckdq.engines.pandas.pandas\_engine module
-------------------------------------------

.. automodule:: duckdq.engines.pandas.pandas_engine
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: duckdq.engines.pandas
   :members:
   :undoc-members:
   :show-inheritance:
