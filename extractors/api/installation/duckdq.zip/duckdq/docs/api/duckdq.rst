duckdq package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   duckdq.core
   duckdq.engines
   duckdq.sklearn
   duckdq.state_handlers
   duckdq.utils

Submodules
----------

duckdq.checks module
--------------------

.. automodule:: duckdq.checks
   :members:
   :undoc-members:
   :show-inheritance:

duckdq.constraints module
-------------------------

.. automodule:: duckdq.constraints
   :members:
   :undoc-members:
   :show-inheritance:

duckdq.verification\_suite module
---------------------------------

.. automodule:: duckdq.verification_suite
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: duckdq
   :members:
   :undoc-members:
   :show-inheritance:
