# -*- coding: utf-8 -*-
"""
Built-in extensions for PyScaffold.
"""
